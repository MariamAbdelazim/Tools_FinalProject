package Entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ResturantEntity {
	@Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int  User_id;
	private String User_name;
	private String User_role;
	private int Meal_id;
	private String Meal_name;
	private int Price;
	private int fk_restaurantId;
	private int Order_id;
	private int Total_price;
	private int fk_runnerId;
	private String Order_status;
	private int Runner_id;
	private String Runner_name;
	private String Runner_status;
	private int Delivery_fees;
	private int Resturant_id;
	private String Resturant_name;
	private int OwnerId;
	private List<String> listOfMeals;
	
	
	
	public int getUser_id() {
		return User_id;
	}
	public void setUser_id(int user_id) {
		User_id = user_id;
	}
	public String getUser_name() {
		return User_name;
	}
	public void setUser_name(String user_name) {
		User_name = user_name;
	}
	public String getUser_role() {
		return User_role;
	}
	public void setUser_role(String user_role) {
		User_role = user_role;
	}
	public int getMeal_id() {
		return Meal_id;
	}
	public void setMeal_id(int meal_id) {
		Meal_id = meal_id;
	}
	public String getMeal_name() {
		return Meal_name;
	}
	public void setMeal_name(String meal_name) {
		Meal_name = meal_name;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public int getRunner_id() {
		return Runner_id;
	}
	public void setRunner_id(int runner_id) {
		Runner_id = runner_id;
	}
	public String getRunner_name() {
		return Runner_name;
	}
	public void setRunner_name(String runner_name) {
		Runner_name = runner_name;
	}
	public String getRunner_status() {
		return Runner_status;
	}
	public void setRunner_status(String runner_status) {
		Runner_status = runner_status;
	}
	public int getDelivery_fees() {
		return Delivery_fees;
	}
	public void setDelivery_fees(int delivery_fees) {
		Delivery_fees = delivery_fees;
	}
	public int getResturant_id() {
		return Resturant_id;
	}
	public void setResturant_id(int resturant_id) {
		Resturant_id = resturant_id;
	}
	public String getResturant_name() {
		return Resturant_name;
	}
	public void setResturant_name(String resturant_name) {
		Resturant_name = resturant_name;
	}
	public List<String> getListOfMeals() {
		return listOfMeals;
	}
	public void setListOfMeals(List<String> listOfMeals) {
		this.listOfMeals = listOfMeals;
	}
	public int getOwnerId() {
		return OwnerId;
	}
	public void setOwnerId(int ownerId) {
		OwnerId = ownerId;
	}
	public int getFk_restaurantId() {
		return fk_restaurantId;
	}
	public void setFk_restaurantId(int fk_restaurantId) {
		this.fk_restaurantId = fk_restaurantId;
	}
	public int getOrder_id() {
		return Order_id;
	}
	public void setOrder_id(int order_id) {
		Order_id = order_id;
	}
	public int getTotal_price() {
		return Total_price;
	}
	public void setTotal_price(int total_price) {
		Total_price = total_price;
	}
	public int getFk_runnerId() {
		return fk_runnerId;
	}
	public void setFk_runnerId(int fk_runnerId) {
		this.fk_runnerId = fk_runnerId;
	}
	public String getOrder_status() {
		return Order_status;
	}
	public void setOrder_status(String order_status) {
		Order_status = order_status;
	}
	
	
	
	 
	
	

}
